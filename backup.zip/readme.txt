11.pack y 8.pack -> frontend/.angular/cache/14.2.8/angular-webpack/f749805996ef50b492a6cbb09ba9362a31044af8
7.pack -> frontend/.angular/cache/14.2.8/angular-webpack/3cb5ceb7085ef8a2b2672ba92f064f05e0910870
